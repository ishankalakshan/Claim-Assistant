Web Based Claims Processing System (WCPS)
=========================================

Courtesy 	: AJProfessionals

Email		: ajprofessionals@gamil.com 

Web Site	: http://ajprofessionals.googlepages.com/ 

Technology	: ASP.Net 2.0, C#, Java Script, SQL Server

Level		: BSC-IT, BIT, DOEACC, BE, BCA, MCA, ME, BE, BTech.

IGNOU Code	: BIT/CSI-22/ASG


Abstract:

Web Based Claims Processing System (WCPS) which is web based so that the employee can fill the form online and submit it so that the form is sent to CPD through Internet. At CPD, the form needs to be checked automatically by a program which will compute the amount that needs to be reimbursed to the employee for the treatment undertaken. 



Note
=================================
This project must be used for academic purpose only. Contact ajprofessionals@gmail.com  for technical support, complete source code, documentation, Synopsis and Project Report of Web Based Claims Processing System (WCPS) at Rs. 1500/- only.

	